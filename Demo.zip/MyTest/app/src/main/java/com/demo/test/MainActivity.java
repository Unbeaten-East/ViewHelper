package com.demo.test;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;
import viewhelper.annotation.*;
import viewhelper.*;

public class MainActivity extends Activity {

	/**注解绑定Button的ID*/
	@BindView(R.id.mainButton1)
	private Button bt;

	/**注解绑定TextView的ID*/
	@BindView(R.id.mainTextView1)
	private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		// 读取字段和方法分析注解绑定的控件来初始化数据
		BindParser.initBind(this);
		// 初始化完成之后就绑定成功了，它们就不再是null了
		bt.setText("按钮");
		tv.setText("文本");
    }

	/**注解绑定TextView和Button的点击事件*/
	@BindClick({R.id.mainButton1,R.id.mainTextView1})
	public void onViewClick(View view){
		switch(view.getId()){
			case R.id.mainButton1:
				((Button)view).setText("点击了按钮");
				break;
			case R.id.mainTextView1:
				((TextView)view).setText("点击了文本");
				break;
		}
	}

}
